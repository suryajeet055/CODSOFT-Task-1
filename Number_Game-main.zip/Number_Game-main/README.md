# Number_Guessing_Game
A simple console-based game where the computer randomly selects a number between 1 and 100, and the player has a limited number of attempts to guess it. After each guess, the player receives feedback on whether their guess was too high, too low, or correct. The game keeps track of score and allows multiple rounds of play.
